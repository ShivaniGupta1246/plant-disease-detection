# Plant-Disease-Identification-using-CNN
# Plant Disease Identification Using Convulutional neural Network

Here is how I built a Plant Disease Detection model using a Convolutional Neural Network .

# For those having issues

For finding DataSet;Go to Kaggle and download the PlantVillage Dataset.

I have included a running version of my code in kaggle link. If you have any problem please refer to that. 
